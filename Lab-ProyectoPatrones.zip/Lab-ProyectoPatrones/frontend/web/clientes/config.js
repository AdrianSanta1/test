const API_BASE = "http://localhost:8000";
const ENDPOINTS = {
    create: "/clientes/",
    read_all: "/clientes/",
    read_one: "/clientes/{id}",
    update: "/clientes/{id}",
    delete: "/clientes/{id}"
};