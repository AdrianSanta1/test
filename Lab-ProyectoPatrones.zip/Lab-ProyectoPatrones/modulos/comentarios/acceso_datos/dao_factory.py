class ComentarioDAOFactory:
    def crear_dao(self):
        raise NotImplementedError